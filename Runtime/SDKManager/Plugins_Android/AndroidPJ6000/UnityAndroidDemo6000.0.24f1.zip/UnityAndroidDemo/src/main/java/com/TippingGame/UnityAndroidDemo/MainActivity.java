package com.TippingGame.UnityAndroidDemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import com.unity3d.player.UnityPlayer;
import com.unity3d.player.UnityPlayerActivity;

public class MainActivity extends UnityPlayerActivity {

    private static final String TAG = "F8Framework";
    private static final String SDKManager = "SDKManager";

    private Activity mActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mActivity = this;
        Log.i(TAG, mActivity.getPackageName().toString());
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

//    @Override
//    public boolean onKeyDown(int keyCode, KeyEvent event) {
//        if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_DOWN) {
//            //拦截返回键，这里做自定义退出
//            return true;
//        }
//        return super.onKeyDown(keyCode, event);
//    }

    public void AndroidToast(String str) {
        Toast.makeText(this, str, Toast.LENGTH_SHORT).show();
    }

    private void CallUnityFunc(String funcName, String paramStr) {
        if (TextUtils.isEmpty(SDKManager)) {
            Log.e(TAG, "gameObject is null, please set gameObject first");
            return;
        }

        UnityPlayer.UnitySendMessage(SDKManager, funcName, paramStr);
    }

    public void SDKInit() {
        Log.i(TAG, "SDKLogin");
    }

    public void SDKLogin() {
        Log.i(TAG, "SDKLogin");
    }

    public void SDKLogout() {
        Log.i(TAG, "SDKLogout");
    }

    public void SDKSwitchAccount() {
        Log.i(TAG, "SDKSwitchAccount");
    }

    public void SDKLoadVideoAd() {
        Log.i(TAG, "SDKLoadVideoAd");
    }

    public void SDKShowVideoAd() {
        Log.i(TAG, "SDKShowVideoAd");
    }

    public void SDKPay(String serverNum, String serverName, String playerId, String playerName, String amount, String extra, String orderId,
                       String productName, String productContent, String playerLevel, String sign, String guid) {
        Log.i(TAG, "SDKPay");
    }

    public void SDKUpdateRoleData(String scenes, String serverId, String serverName, String roleId, String roleName,
                                  String roleLeve, String roleCTime, String rolePower, String guid) {
        Log.i(TAG, "SDKUpdateRoleData");
    }

    public void SDKExit() {
        Log.i(TAG, "SDKExit");
    }


}
