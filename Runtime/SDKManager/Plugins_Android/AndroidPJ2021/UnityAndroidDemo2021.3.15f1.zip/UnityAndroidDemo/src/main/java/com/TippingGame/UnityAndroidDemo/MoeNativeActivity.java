package com.TippingGame.UnityAndroidDemo;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MoeNativeActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (!isTaskRoot()) {
            Intent intent = getIntent();
            String action = intent.getAction();
            if (intent.hasCategory(Intent.CATEGORY_LAUNCHER) && action != null && action.equals(Intent.ACTION_MAIN)) {
                finish();
                return;
            }
        }

        Boolean anInt = false;

        // 隐私协议相关
        SharedPreferences base = getSharedPreferences("base", MODE_PRIVATE);
        anInt = base.getBoolean("isFirstStart", true);

        if (anInt == true) {
            AlertDialog.Builder dialog = new AlertDialog.Builder(MoeNativeActivity.this);
            dialog.setTitle("隐私协议");  //设置标题

            ScrollView scrollView = new ScrollView(this);
            TextView tv = new TextView(this);
            tv.setText(R.string.main_content);
            tv.setMovementMethod(LinkMovementMethod.getInstance());
            tv.setTextColor(Color.BLACK);  // 设置文本颜色
            scrollView.addView(tv);

            dialog.setView(scrollView);

            dialog.setCancelable(false);  //是否可以取消
            // 设置拒绝按钮（放在左边）
            dialog.setNegativeButton("拒绝", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                    finish();
                    android.os.Process.killProcess(android.os.Process.myPid());
                }
            });

            // 设置同意按钮（放在右边）
            dialog.setPositiveButton("同意", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    SharedPreferences.Editor editor = base.edit();
                    editor.putBoolean("isFirstStart", false);
                    editor.commit();

                    // 玩家点击同意后，跳转到 Unity 的 Activity
                    Intent intent = new Intent(MoeNativeActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                }
            });

            // 创建对话框
            AlertDialog alertDialog = dialog.create();

            // 设置按钮文本居中并左右自适应
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.FROYO) {
                alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
                    @Override
                    public void onShow(DialogInterface dialogInterface) {
                        Button positiveButton = alertDialog.getButton(DialogInterface.BUTTON_POSITIVE);
                        Button negativeButton = alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE);
                        if (positiveButton != null && negativeButton != null) {
                            // 设置按钮文本居中
                            positiveButton.setGravity(Gravity.CENTER);
                            negativeButton.setGravity(Gravity.CENTER);
                            // 设置按钮左右自适应
                            positiveButton.setLayoutParams(new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.WRAP_CONTENT,
                                    LinearLayout.LayoutParams.WRAP_CONTENT,
                                    Gravity.CENTER));
                            negativeButton.setLayoutParams(new LinearLayout.LayoutParams(
                                    LinearLayout.LayoutParams.WRAP_CONTENT,
                                    LinearLayout.LayoutParams.WRAP_CONTENT,
                                    Gravity.CENTER));
                        }
                    }
                });
            }

            alertDialog.show();

        } else {
            // 已经同意过了，直接跳转到 Unity 的 Activity
            Intent intent = new Intent(MoeNativeActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        }
    }
}

